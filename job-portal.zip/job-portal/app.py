from flask import Flask, render_template, request, redirect, url_for, flash, send_file
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from datetime import datetime
import os

# Initialize Flask app
app = Flask(__name__)

# Configuration
app.config['SECRET_KEY'] = 'your-secret-key-change-in-production'
# PostgreSQL Configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:1234@localhost:5432/jobportal'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'uploads/resumes'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB

# Initialize extensions
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Please log in to access this page.'
login_manager.login_message_category = 'warning'

# Ensure upload folder exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# ==================== DATABASE MODELS ====================

class User(UserMixin, db.Model):
    """User model for both job seekers and employers"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # 'jobseeker' or 'employer'
    
    # Common fields
    phone = db.Column(db.String(20))
    location = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Job seeker fields
    skills = db.Column(db.Text)
    experience = db.Column(db.Text)
    education = db.Column(db.Text)
    resume_file = db.Column(db.String(200))
    
    # Employer fields
    company_name = db.Column(db.String(100))
    company_description = db.Column(db.Text)
    industry = db.Column(db.String(100))
    company_size = db.Column(db.String(20))
    website = db.Column(db.String(200))
    founded_year = db.Column(db.Integer)
    linkedin = db.Column(db.String(200))
    twitter = db.Column(db.String(100))
    
    # Relationships
    jobs = db.relationship('Job', backref='employer', lazy=True, cascade='all, delete-orphan')
    applications = db.relationship('Application', backref='seeker', lazy=True, cascade='all, delete-orphan')

class Job(db.Model):
    """Job posting model"""
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    location = db.Column(db.String(100), nullable=False)
    skills = db.Column(db.Text, nullable=False)
    salary_range = db.Column(db.String(100))
    job_type = db.Column(db.String(50), default='Full-time')
    experience_level = db.Column(db.String(50))
    employer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    
    # Relationships
    applications = db.relationship('Application', backref='job', lazy=True, cascade='all, delete-orphan')

class Application(db.Model):
    """Job application model"""
    id = db.Column(db.Integer, primary_key=True)
    job_id = db.Column(db.Integer, db.ForeignKey('job.id'), nullable=False)
    seeker_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    resume_file = db.Column(db.String(200), nullable=False)
    cover_letter = db.Column(db.Text)
    status = db.Column(db.String(50), default='pending')
    applied_at = db.Column(db.DateTime, default=datetime.utcnow)

# ==================== LOGIN MANAGER ====================

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# ==================== HELPER FUNCTIONS ====================

def allowed_file(filename):
    ALLOWED_EXTENSIONS = {'pdf', 'doc', 'docx'}
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# ==================== PUBLIC ROUTES ====================

@app.route('/')
def index():
    """Homepage"""
    jobs = Job.query.filter_by(is_active=True).order_by(Job.created_at.desc()).limit(6).all()
    return render_template('index.html', jobs=jobs)

@app.route('/register', methods=['GET', 'POST'])
def register():
    """User registration"""
    if current_user.is_authenticated:
        if current_user.role == 'employer':
            return redirect(url_for('employer_dashboard'))
        return redirect(url_for('jobseeker_dashboard'))
    
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        password = request.form.get('password')
        role = request.form.get('role')
        
        if not all([name, email, password, role]):
            flash('All fields are required!', 'error')
            return redirect(url_for('register'))
        
        if role not in ['jobseeker', 'employer']:
            flash('Invalid role selected!', 'error')
            return redirect(url_for('register'))
        
        if User.query.filter_by(email=email).first():
            flash('Email already registered!', 'error')
            return redirect(url_for('register'))
        
        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
        new_user = User(name=name, email=email, password=hashed_password, role=role)
        
        try:
            db.session.add(new_user)
            db.session.commit()
            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            db.session.rollback()
            flash('An error occurred. Please try again.', 'error')
            print(f"Registration error: {e}")
            return redirect(url_for('register'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """User login"""
    if current_user.is_authenticated:
        if current_user.role == 'employer':
            return redirect(url_for('employer_dashboard'))
        return redirect(url_for('jobseeker_dashboard'))
    
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        if not email or not password:
            flash('Email and password are required!', 'error')
            return redirect(url_for('login'))
        
        user = User.query.filter_by(email=email).first()
        
        if user and check_password_hash(user.password, password):
            login_user(user)
            flash(f'Welcome back, {user.name}!', 'success')
            
            if user.role == 'employer':
                return redirect(url_for('employer_dashboard'))
            else:
                return redirect(url_for('jobseeker_dashboard'))
        else:
            flash('Invalid email or password!', 'error')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    """User logout"""
    logout_user()
    flash('Logged out successfully!', 'success')
    return redirect(url_for('index'))

@app.route('/jobs')
def jobs():
    """Browse all jobs"""
    search = request.args.get('search', '')
    location = request.args.get('location', '')
    skills = request.args.get('skills', '')
    
    query = Job.query.filter_by(is_active=True)
    
    if search:
        query = query.filter(Job.title.ilike(f'%{search}%'))
    if location:
        query = query.filter(Job.location.ilike(f'%{location}%'))
    if skills:
        query = query.filter(Job.skills.ilike(f'%{skills}%'))
    
    jobs = query.order_by(Job.created_at.desc()).all()
    return render_template('jobs.html', jobs=jobs)

@app.route('/job/<int:job_id>')
def job_detail(job_id):
    """View job details"""
    job = Job.query.get_or_404(job_id)
    has_applied = False
    
    if current_user.is_authenticated and current_user.role == 'jobseeker':
        has_applied = Application.query.filter_by(job_id=job_id, seeker_id=current_user.id).first() is not None
    
    return render_template('job_detail.html', job=job, has_applied=has_applied)

# ==================== JOB SEEKER ROUTES ====================

@app.route('/jobseeker/dashboard')
@login_required
def jobseeker_dashboard():
    """Job seeker dashboard"""
    if current_user.role != 'jobseeker':
        flash('Access denied!', 'error')
        return redirect(url_for('employer_dashboard'))
    
    applications = Application.query.filter_by(seeker_id=current_user.id).order_by(Application.applied_at.desc()).all()
    return render_template('jobseeker_dashboard.html', applications=applications)

@app.route('/jobseeker/profile', methods=['GET', 'POST'])
@login_required
def jobseeker_profile():
    """Job seeker profile"""
    if current_user.role != 'jobseeker':
        flash('Access denied!', 'error')
        return redirect(url_for('employer_dashboard'))
    
    if request.method == 'POST':
        current_user.phone = request.form.get('phone', '')
        current_user.location = request.form.get('location', '')
        current_user.skills = request.form.get('skills', '')
        current_user.experience = request.form.get('experience', '')
        current_user.education = request.form.get('education', '')
        
        if 'resume' in request.files:
            file = request.files['resume']
            if file and file.filename and allowed_file(file.filename):
                filename = secure_filename(f"{current_user.id}_{int(datetime.now().timestamp())}_{file.filename}")
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(filepath)
                current_user.resume_file = filename
        
        try:
            db.session.commit()
            flash('Profile updated successfully!', 'success')
        except Exception as e:
            db.session.rollback()
            flash('Error updating profile!', 'error')
            print(f"Error: {e}")
        
        return redirect(url_for('jobseeker_profile'))
    
    return render_template('jobseeker_profile.html')

@app.route('/job/<int:job_id>/apply', methods=['GET', 'POST'])
@login_required
def apply_job(job_id):
    """Apply for job"""
    if current_user.role != 'jobseeker':
        flash('Only job seekers can apply!', 'error')
        return redirect(url_for('job_detail', job_id=job_id))
    
    job = Job.query.get_or_404(job_id)
    
    existing = Application.query.filter_by(job_id=job_id, seeker_id=current_user.id).first()
    if existing:
        flash('You already applied for this job!', 'warning')
        return redirect(url_for('job_detail', job_id=job_id))
    
    if request.method == 'POST':
        cover_letter = request.form.get('cover_letter', '')
        resume_file = current_user.resume_file
        
        if 'resume' in request.files:
            file = request.files['resume']
            if file and file.filename and allowed_file(file.filename):
                filename = secure_filename(f"{current_user.id}_{int(datetime.now().timestamp())}_{file.filename}")
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(filepath)
                resume_file = filename
        
        if not resume_file:
            flash('Please upload a resume!', 'error')
            return redirect(url_for('apply_job', job_id=job_id))
        
        application = Application(
            job_id=job_id,
            seeker_id=current_user.id,
            resume_file=resume_file,
            cover_letter=cover_letter
        )
        
        try:
            db.session.add(application)
            db.session.commit()
            flash('Application submitted successfully!', 'success')
            return redirect(url_for('jobseeker_dashboard'))
        except Exception as e:
            db.session.rollback()
            flash('Error submitting application!', 'error')
            print(f"Error: {e}")
    
    return render_template('apply_job.html', job=job)

# ==================== EMPLOYER ROUTES ====================

@app.route('/employer/dashboard')
@login_required
def employer_dashboard():
    """Employer dashboard"""
    if current_user.role != 'employer':
        flash('Access denied!', 'error')
        return redirect(url_for('jobseeker_dashboard'))
    
    jobs = Job.query.filter_by(employer_id=current_user.id).order_by(Job.created_at.desc()).all()
    
    # Calculate total applications
    total_applications = sum(len(job.applications) for job in jobs)
    
    return render_template('employer_dashboard.html', jobs=jobs, total_applications=total_applications)

@app.route('/employer/profile', methods=['GET', 'POST'])
@login_required
def employer_profile():
    """Employer profile"""
    if current_user.role != 'employer':
        flash('Access denied!', 'error')
        return redirect(url_for('jobseeker_dashboard'))
    
    if request.method == 'POST':
        current_user.company_name = request.form.get('company_name', '')
        current_user.company_description = request.form.get('company_description', '')
        current_user.phone = request.form.get('phone', '')
        current_user.location = request.form.get('location', '')
        
        try:
            db.session.commit()
            flash('Profile updated successfully!', 'success')
        except Exception as e:
            db.session.rollback()
            flash('Error updating profile!', 'error')
            print(f"Error: {e}")
        
        return redirect(url_for('employer_profile'))
    
    return render_template('employer_profile.html')

@app.route('/employer/job/post', methods=['GET', 'POST'])
@login_required
def post_job():
    """Post new job"""
    if current_user.role != 'employer':
        flash('Only employers can post jobs!', 'error')
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        title = request.form.get('title', '')
        description = request.form.get('description', '')
        location = request.form.get('location', '')
        skills = request.form.get('skills', '')
        salary_range = request.form.get('salary_range', '')
        job_type = request.form.get('job_type', 'Full-time')
        experience_level = request.form.get('experience_level', '')
        
        if not all([title, description, location, skills]):
            flash('Please fill all required fields!', 'error')
            return redirect(url_for('post_job'))
        
        job = Job(
            title=title,
            description=description,
            location=location,
            skills=skills,
            salary_range=salary_range,
            job_type=job_type,
            experience_level=experience_level,
            employer_id=current_user.id
        )
        
        try:
            db.session.add(job)
            db.session.commit()
            flash('Job posted successfully!', 'success')
            return redirect(url_for('employer_dashboard'))
        except Exception as e:
            db.session.rollback()
            flash('Error posting job!', 'error')
            print(f"Error: {e}")
    
    return render_template('post_job.html')

@app.route('/employer/job/<int:job_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_job(job_id):
    """Edit job"""
    if current_user.role != 'employer':
        flash('Access denied!', 'error')
        return redirect(url_for('index'))
    
    job = Job.query.get_or_404(job_id)
    
    if job.employer_id != current_user.id:
        flash('You can only edit your own jobs!', 'error')
        return redirect(url_for('employer_dashboard'))
    
    if request.method == 'POST':
        job.title = request.form.get('title', job.title)
        job.description = request.form.get('description', job.description)
        job.location = request.form.get('location', job.location)
        job.skills = request.form.get('skills', job.skills)
        job.salary_range = request.form.get('salary_range', job.salary_range)
        job.job_type = request.form.get('job_type', job.job_type)
        job.experience_level = request.form.get('experience_level', job.experience_level)
        
        try:
            db.session.commit()
            flash('Job updated successfully!', 'success')
            return redirect(url_for('employer_dashboard'))
        except Exception as e:
            db.session.rollback()
            flash('Error updating job!', 'error')
            print(f"Error: {e}")
    
    return render_template('edit_job.html', job=job)

@app.route('/employer/job/<int:job_id>/delete', methods=['POST'])
@login_required
def delete_job(job_id):
    """Delete job"""
    if current_user.role != 'employer':
        flash('Access denied!', 'error')
        return redirect(url_for('index'))
    
    job = Job.query.get_or_404(job_id)
    
    if job.employer_id != current_user.id:
        flash('You can only delete your own jobs!', 'error')
        return redirect(url_for('employer_dashboard'))
    
    try:
        db.session.delete(job)
        db.session.commit()
        flash('Job deleted successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Error deleting job!', 'error')
        print(f"Error: {e}")
    
    return redirect(url_for('employer_dashboard'))

@app.route('/employer/job/<int:job_id>/applicants')
@login_required
def view_applicants(job_id):
    """View applicants"""
    if current_user.role != 'employer':
        flash('Access denied!', 'error')
        return redirect(url_for('index'))
    
    job = Job.query.get_or_404(job_id)
    
    if job.employer_id != current_user.id:
        flash('You can only view applicants for your own jobs!', 'error')
        return redirect(url_for('employer_dashboard'))
    
    applications = Application.query.filter_by(job_id=job_id).order_by(Application.applied_at.desc()).all()
    return render_template('view_applicants.html', job=job, applications=applications)

@app.route('/employer/application/<int:application_id>/status', methods=['POST'])
@login_required
def update_application_status(application_id):
    """Update application status"""
    if current_user.role != 'employer':
        flash('Access denied!', 'error')
        return redirect(url_for('index'))
    
    application = Application.query.get_or_404(application_id)
    job = Job.query.get(application.job_id)
    
    if job.employer_id != current_user.id:
        flash('Access denied!', 'error')
        return redirect(url_for('employer_dashboard'))
    
    new_status = request.form.get('status')
    
    if new_status in ['pending', 'reviewed', 'accepted', 'rejected']:
        application.status = new_status
        try:
            db.session.commit()
            flash(f'Status updated to {new_status}!', 'success')
        except Exception as e:
            db.session.rollback()
            flash('Error updating status!', 'error')
            print(f"Error: {e}")
    
    return redirect(url_for('view_applicants', job_id=job.id))

# ==================== FILE DOWNLOAD ====================

@app.route('/download/resume/<filename>')
@login_required
def download_resume(filename):
    """Download resume"""
    try:
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        if os.path.exists(filepath):
            return send_file(filepath, as_attachment=True)
        else:
            flash('Resume not found!', 'error')
            return redirect(request.referrer or url_for('index'))
    except Exception as e:
        flash('Error downloading resume!', 'error')
        print(f"Error: {e}")
        return redirect(request.referrer or url_for('index'))

# ==================== ERROR HANDLERS ====================

@app.errorhandler(404)
def not_found(error):
    flash('Page not found!', 'error')
    return redirect(url_for('index'))

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    flash('An error occurred!', 'error')
    return redirect(url_for('index'))

# ==================== MAIN ====================

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        print("✅ Database created successfully!")
        print("🚀 Server starting...")
        print("📍 Go to: http://127.0.0.1:5000")
    
    app.run(debug=True, host='0.0.0.0', port=5000)